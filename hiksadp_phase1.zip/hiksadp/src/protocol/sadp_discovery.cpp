// Qt headers di .cpp saja — moc hanya memproses file yang di-list di CMake
#include <QCoreApplication>
#include <QHostAddress>
#include <QNetworkInterface>
#include <QNetworkAddressEntry>
#include <QObject>
#include <QTimer>
#include <QUdpSocket>

#include "sadp_discovery.hpp"
#include <format>
#include <unordered_map>

namespace hiksadp::protocol {

// ── get_active_interfaces ──────────────────────────────────────────────────

std::vector<NetworkInterface> get_active_interfaces()
{
    std::vector<NetworkInterface> result;
    for (const auto& qt_iface : QNetworkInterface::allInterfaces()) {
        const auto flags = qt_iface.flags();
        if (!flags.testFlag(QNetworkInterface::IsUp))      continue;
        if (!flags.testFlag(QNetworkInterface::IsRunning)) continue;
        if (flags.testFlag(QNetworkInterface::IsLoopBack)) continue;

        for (const auto& entry : qt_iface.addressEntries()) {
            if (entry.ip().protocol() != QAbstractSocket::IPv4Protocol) continue;
            if (entry.broadcast().isNull()) continue;

            NetworkInterface iface;
            iface.name      = qt_iface.name().toStdString();
            iface.address   = IpAddress{entry.ip().toString().toStdString()};
            iface.broadcast = IpAddress{entry.broadcast().toString().toStdString()};
            iface.is_up     = true;
            result.push_back(std::move(iface));
        }
    }
    return result;
}

// ── SadpWorker — QObject tersembunyi di dalam pimpl ───────────────────────

class SadpWorker : public QObject {
    Q_OBJECT
public:
    explicit SadpWorker(QObject* parent = nullptr) : QObject{parent} {}

    std::unique_ptr<QUdpSocket> socket;
    std::unique_ptr<QTimer>     timeout_timer;
    std::unique_ptr<QTimer>     auto_refresh_timer;
};

// ── SadpDiscovery::Impl ────────────────────────────────────────────────────

struct SadpDiscovery::Impl {
    SadpWorker* worker{nullptr}; // owned by Qt parent chain

    std::optional<NetworkInterface> selected_interface;
    int    timeout_ms{SadpDiscovery::DEFAULT_TIMEOUT_MS};
    bool   auto_refresh{false};
    bool   scanning{false};
    std::uint16_t sequence_number{0};

    std::unordered_map<std::string, Device> current_scan_devices;
    std::unordered_map<std::string, Device> known_devices;
    DiscoveryResult current_result;

    SadpDiscovery::DeviceFoundCallback  cb_device_found;
    SadpDiscovery::ScanCompleteCallback cb_scan_complete;
    SadpDiscovery::ErrorCallback        cb_error;

    // Pointer ke owner untuk memanggil methods
    SadpDiscovery* owner{nullptr};

    void init_worker() {
        worker = new SadpWorker{};
        worker->socket       = std::make_unique<QUdpSocket>(worker);
        worker->timeout_timer       = std::make_unique<QTimer>(worker);
        worker->auto_refresh_timer  = std::make_unique<QTimer>(worker);

        worker->timeout_timer->setSingleShot(true);
        worker->auto_refresh_timer->setInterval(SadpDiscovery::AUTO_REFRESH_MS);

        QObject::connect(worker->socket.get(), &QUdpSocket::readyRead,
            [this]() { on_ready_read(); });

        QObject::connect(worker->timeout_timer.get(), &QTimer::timeout,
            [this]() { finalize_scan(); });

        QObject::connect(worker->auto_refresh_timer.get(), &QTimer::timeout,
            [this]() {
                if (!scanning) {
                    auto r = owner->start_scan();
                    if (!r && cb_error) cb_error(r.error());
                }
            });
    }

    Result<void> init_socket() {
        if (!worker->socket->bind(
                QHostAddress::AnyIPv4,
                ports::SADP_DISCOVERY.get(),
                QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint))
        {
            return make_error<void>(ErrorCode::SocketBindFailed,
                worker->socket->errorString().toStdString());
        }
        return Result<void>{};
    }

    Result<void> send_broadcast() {
        auto packet_result = PacketBuilder::build_inquiry(sequence_number++);
        if (!packet_result) return std::unexpected(packet_result.error());

        const auto& packet = packet_result.value();
        QByteArray qt_packet(
            reinterpret_cast<const char*>(packet.data()),
            static_cast<qsizetype>(packet.size()));

        std::vector<QString> addrs;
        if (selected_interface) {
            addrs.push_back(QString::fromStdString(selected_interface->broadcast.get()));
        } else {
            for (const auto& iface : get_active_interfaces())
                addrs.push_back(QString::fromStdString(iface.broadcast.get()));
            addrs.push_back("255.255.255.255");
        }

        int sent = 0;
        for (const auto& addr : addrs) {
            if (worker->socket->writeDatagram(
                    qt_packet, QHostAddress{addr},
                    ports::SADP_DISCOVERY.get()) > 0)
                ++sent;
        }

        current_result.packets_sent = sent;
        if (sent == 0)
            return make_error<void>(ErrorCode::BroadcastFailed);

        return Result<void>{};
    }

    void on_ready_read() {
        while (worker->socket->hasPendingDatagrams()) {
            QByteArray  datagram;
            QHostAddress sender;
            quint16 sender_port;
            datagram.resize(static_cast<qsizetype>(
                worker->socket->pendingDatagramSize()));
            worker->socket->readDatagram(datagram.data(), datagram.size(),
                                          &sender, &sender_port);
            process_datagram(datagram);
        }
    }

    void process_datagram(const QByteArray& data) {
        std::span<const std::byte> raw{
            reinterpret_cast<const std::byte*>(data.constData()),
            static_cast<std::size_t>(data.size())};

        auto parse_result = PacketParser::parse_inquiry_reply(raw);
        if (!parse_result) return;

        const auto& info    = parse_result.value();
        const auto  mac_key = info.mac_address.get();
        if (current_scan_devices.contains(mac_key)) return;

        Device device;
        device.serial_number    = info.serial_number;
        device.mac_address      = info.mac_address;
        device.firmware_version = info.firmware_version;
        device.model            = info.model;
        device.device_type      = info.device_type;
        device.last_seen        = std::chrono::steady_clock::now();
        device.network.ip          = info.ip_address;
        device.network.subnet_mask = info.subnet_mask;
        device.network.gateway     = info.gateway;
        device.network.http_port   = info.http_port;
        device.network.sdk_port    = info.sdk_port;
        device.network.dhcp_enabled = info.dhcp_enabled;
        device.state = info.is_inactive
            ? DeviceState{StateInactive{}}
            : DeviceState{StateActive{}};

        current_scan_devices.emplace(mac_key, device);
        known_devices[mac_key] = device;
        ++current_result.responses_received;

        if (cb_device_found) cb_device_found(device);
    }

    void finalize_scan() {
        scanning = false;
        current_result.devices.clear();
        current_result.devices.reserve(current_scan_devices.size());
        for (const auto& [_, dev] : current_scan_devices)
            current_result.devices.push_back(dev);

        if (cb_scan_complete) cb_scan_complete(current_result);

        if (auto_refresh && !worker->auto_refresh_timer->isActive())
            worker->auto_refresh_timer->start();
    }
};

// ── SadpDiscovery public methods ───────────────────────────────────────────

SadpDiscovery::SadpDiscovery()
    : impl_{std::make_unique<Impl>()}
{
    impl_->owner = this;
    impl_->init_worker();
}

SadpDiscovery::~SadpDiscovery() { stop(); }

void SadpDiscovery::set_interface(const NetworkInterface& iface) {
    impl_->selected_interface = iface;
}
void SadpDiscovery::set_timeout(int ms)   { impl_->timeout_ms = ms; }
void SadpDiscovery::set_auto_refresh(bool en) {
    impl_->auto_refresh = en;
    if (en) impl_->worker->auto_refresh_timer->start();
    else    impl_->worker->auto_refresh_timer->stop();
}

void SadpDiscovery::on_device_found(DeviceFoundCallback cb)
    { impl_->cb_device_found = std::move(cb); }
void SadpDiscovery::on_scan_complete(ScanCompleteCallback cb)
    { impl_->cb_scan_complete = std::move(cb); }
void SadpDiscovery::on_error(ErrorCallback cb)
    { impl_->cb_error = std::move(cb); }

Result<void> SadpDiscovery::start_scan() {
    if (impl_->scanning) return Result<void>{};

    if (impl_->worker->socket->state() != QAbstractSocket::BoundState) {
        auto r = impl_->init_socket();
        if (!r) return r;
    }

    impl_->current_scan_devices.clear();
    impl_->current_result = DiscoveryResult{};
    impl_->current_result.scan_time = std::chrono::steady_clock::now();
    impl_->current_result.interface_used =
        impl_->selected_interface ? impl_->selected_interface->name : "all";
    impl_->scanning = true;

    auto r = impl_->send_broadcast();
    if (!r) {
        impl_->scanning = false;
        if (impl_->cb_error) impl_->cb_error(r.error());
        return r;
    }

    impl_->worker->timeout_timer->start(impl_->timeout_ms);
    return Result<void>{};
}

void SadpDiscovery::stop() {
    impl_->worker->timeout_timer->stop();
    impl_->worker->auto_refresh_timer->stop();
    impl_->scanning = false;
    if (impl_->worker->socket->state() != QAbstractSocket::UnconnectedState)
        impl_->worker->socket->close();
}

bool SadpDiscovery::is_scanning() const noexcept { return impl_->scanning; }

std::vector<Device> SadpDiscovery::last_discovered() const {
    std::vector<Device> out;
    out.reserve(impl_->known_devices.size());
    for (const auto& [_, dev] : impl_->known_devices)
        out.push_back(dev);
    return out;
}

} // namespace hiksadp::protocol

// moc requires this at end of .cpp when using Q_OBJECT inside .cpp
#include "sadp_discovery.moc"
