#include "protocol/sadp_discovery.hpp"
#include "core/device.hpp"

#include <QCoreApplication>
#include <QTimer>

#include <format>
#include <iostream>
#include <iomanip>

using namespace hiksadp;
using namespace hiksadp::protocol;

// ── Terminal formatting helpers ────────────────────────────────────────────

static void print_separator(char ch = '-', int width = 100) {
    std::cout << std::string(static_cast<std::size_t>(width), ch) << "\n";
}

static void print_header() {
    print_separator('=');
    std::cout << "  HikSADP Linux — Device Scanner v1.0\n";
    std::cout << "  Hikvision SADP Tool alternative for Linux\n";
    print_separator('=');
    std::cout << "\n";
}

static void print_device_table_header() {
    print_separator();
    std::cout << std::left
              << std::setw(18) << "IP Address"
              << std::setw(20) << "MAC Address"
              << std::setw(22) << "Serial Number"
              << std::setw(20) << "Model"
              << std::setw(12) << "Status"
              << std::setw(10) << "HTTP Port"
              << "Firmware\n";
    print_separator();
}

static void print_device(const Device& d) {
    std::cout << std::left
              << std::setw(18) << d.network.ip.get()
              << std::setw(20) << d.mac_address.get()
              << std::setw(22) << d.serial_number.get()
              << std::setw(20) << d.model
              << std::setw(12) << d.status_string()
              << std::setw(10) << d.network.http_port.get()
              << d.firmware_version.get()
              << "\n";
}

static void print_interfaces() {
    const auto ifaces = get_active_interfaces();
    std::cout << "Network interfaces yang digunakan:\n";
    for (const auto& iface : ifaces) {
        std::cout << std::format("  {} — {} (broadcast: {})\n",
            iface.name, iface.address.get(), iface.broadcast.get());
    }
    std::cout << "\n";
}

// ── main ───────────────────────────────────────────────────────────────────

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);
    app.setApplicationName("HikSADP Linux");
    app.setApplicationVersion("1.0.0");

    print_header();
    print_interfaces();

    std::cout << "Scanning jaringan...\n\n";

    auto scanner = std::make_unique<SadpDiscovery>();
    int device_count = 0;
    bool header_printed = false;

    // Callback: device ditemukan satu per satu
    scanner->on_device_found([&](const Device& device) {
        if (!header_printed) {
            print_device_table_header();
            header_printed = true;
        }
        print_device(device);
        ++device_count;
    });

    // Callback: scan selesai
    scanner->on_scan_complete([&](const DiscoveryResult& result) {
        if (header_printed) {
            print_separator();
        }

        if (device_count == 0) {
            std::cout << "Tidak ada perangkat Hikvision yang ditemukan di jaringan.\n";
            std::cout << "Pastikan:\n";
            std::cout << "  1. Perangkat terhubung ke jaringan yang sama\n";
            std::cout << "  2. Firewall tidak memblokir UDP port 37020\n";
            std::cout << "  3. Coba jalankan dengan sudo jika masalah persists\n";
        } else {
            std::cout << std::format("\nTotal: {} perangkat ditemukan", device_count);
            std::cout << std::format(" (scan selesai dalam ~{} detik)\n",
                result.packets_sent > 0 ? "4.5" : "0");

            // Ringkasan status
            int inactive_count = 0;
            for (const auto& dev : result.devices) {
                if (is_inactive(dev.state)) ++inactive_count;
            }

            if (inactive_count > 0) {
                std::cout << std::format(
                    "\nPeringatan: {} perangkat belum diaktivasi (status: Inactive)\n",
                    inactive_count);
                std::cout << "Gunakan HikSADP Linux GUI untuk mengaktivasi perangkat tersebut.\n";
            }
        }

        std::cout << "\n";

        // Selesai — exit
        QTimer::singleShot(0, &app, &QCoreApplication::quit);
    });

    // Callback: error
    scanner->on_error([&](const AppError& err) {
        std::cerr << std::format("Error: {}\n", err.message());
        QTimer::singleShot(0, &app, &QCoreApplication::quit);
    });

    // Mulai scan
    auto scan_result = scanner->start_scan();
    if (!scan_result) {
        std::cerr << std::format("Gagal memulai scan: {}\n",
                                  scan_result.error().message());
        return 1;
    }

    return app.exec();
}
